package com.Runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		glue= {"com.StepDefinTestCases"},
       

features="Features",
    //    tags = {"@PayUser_DataTable"},
        format= {"pretty", "html:Reports",
        		"json:Reports/cucumber.json",
        		"junit:Reports/cucumber.xml"
        		},
         strict=false,
		 monochrome=true,
		 dryRun = true
		)



public class PayUserRunner {

}
