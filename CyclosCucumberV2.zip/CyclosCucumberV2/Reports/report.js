$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CyclosFunctioanlTest.feature");
formatter.feature({
  "line": 2,
  "name": "This is to validate the functionalities of CyclosWebsite",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@FunctionalTests"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Validate whether payment is being made to existing user is successful",
  "description": "",
  "id": "this-is-to-validate-the-functionalities-of-cycloswebsite;validate-whether-payment-is-being-made-to-existing-user-is-successful",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@PayUser_DataTable"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Required website is launched also business user is able to loggin with the authorized credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "Following are the payment details",
  "rows": [
    {
      "cells": [
        "User(quick search)",
        "Amount"
      ],
      "line": 8
    },
    {
      "cells": [
        "Nicola Tesla",
        "15"
      ],
      "line": 9
    },
    {
      "cells": [
        "Hotel Oasis",
        "20"
      ],
      "line": 10
    },
    {
      "cells": [
        "Henry George",
        "30"
      ],
      "line": 11
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "System is able to make the desired payment",
  "keyword": "Then "
});
formatter.match({
  "location": "PayUserDataTableTC1.required_website_is_launched_also_business_user_is_able_to_loggin_with_the_authorized_credentials()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "PayUserDataTableTC1.following_are_the_payment_details(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "PayUserDataTableTC1.system_is_able_to_make_the_desired_payment()"
});
formatter.result({
  "status": "skipped"
});
});